/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

// *******************************************************************************/
// import java.util.*;
// public class Main
// {
// 	public static void main(String[] args) {
// // 		System.out.println("Hello World");
// Scanner sc=new Scanner (System.in);
// int n=sc.nextInt();
// int m=sc.nextInt();
                                                // 4star pattern
// for(int i=1;i<=n;i++){
//     for(int j=1;j<=n;j++){
//         System.out.print("*");
//     }
//     System.out.println();
// }
                                               // stars with space
        //          System.out.println();
        //      System.out.print(" ");    
        //      }
        //      for(int j=1;j==i;j++){
        //      }
        //      for(int j=2;j<=i;j++){
        //       System.out.print(j);  
        //      }
        //      System.out.println();
        //  }        
                                            //   Triangle space between stars n=5
        //   class Main{
        //         int n=5;                       
        //  for(int i=n;i>=1;i--){
        //      for(int j=1;j<=n;j++){
        //          if(j==(n-(i-1)) || i==n ||j==n){
        //          System.out.print("*");
        //          }
        //          else{
        //          System.out.print(" ");
        //          }
        //      }
        //      System.out.println();
        //  }
        //   }
        
                                               //  Butterfly pattern n==4,m==8. m should double of n
                                
//                                               for(int i=1;i<=n;i++){
//                                                   for(int j=1;j<=i;j++){
//                                                   System.out.print("*");
//                                                   }
//                                                   for(int j=1;j<=m-2*i;j++){
//                                                       System.out.print(" ");
//                                                   }
//                                                   for(int j=1;j<=i;j++){
//                                                       System.out.print("*");
//                                                   }
//                                                   System.out.println();
//                                               }
//                                                 for(int i=n;i>=1;i--){
//                                                   for(int j=1;j<=i;j++){
//                                                   System.out.print("*");
//                                                   }
//                                                   for(int j=1;j<=m-2*i;j++){
//                                                       System.out.print(" ");
//                                                   }
//                                                   for(int j=1;j<=i;j++){
//                                                       System.out.print("*");
//                                                   }
//                                                   System.out.println();
//                                               }
                                               
                             
// 	}
// }
                                         //   palogram pattern
// import java.util.*;
// public class Main
// {
// 	public static void main(String[] args) {
// // 		System.out.println("Hello World");
// Scanner sc=new Scanner (System.in);
// int n=sc.nextInt();
// // int m=sc.nextInt();
// for(int i=1;i<=n;i++){
//     for(int j=1;j<=(n-i);j++){
//         System.out.print(" ");
//     }
//     for(int j=1;j<=n;j++){
//          System.out.print("*");
//     }
//      System.out.println();
// }

// }
// }
                            // Alphabeticle Reverse order
// class Main{
//     public  static void main(String[]args){              A B C D E
//     for(char i='E';i>='A';i-- ){                         A B C D
//         for(char c='A';c<=i;c++){                        A B c
//             System.out.print(c+" ");                     A B
//         }                                                A
//         System.out.println();
//     }
//     }
// }

                                // Combination Of Alphabetes And Numerics
class Main{
    public  static void main(String[]args){                 
    for(int i=1;i<=5;i++ ){                                
        for(int j=1;j<=i;j++){ 
            if(i%2!=0){
            System.out.print((char)(j+64)+" "); 
            }
            else{
                System.out.print(j+" ");
            }
        }    
        System.out.println();
    }
    }
}
                            // Combination Of Alphabetes And Numerics

/*class Main{
    public  static void main(String[]args){                 
    for(int i=1;i<=5;i++ ){                                
        for(int j=1;j<=i;j++){ 
            if(i%2!=0){
            System.out.print(j+" "); 
            }
            else{
                System.out.print((char)(j+64)+" ");
            }
        }    
        System.out.println();
        // System.out.println(i-64);
    }
    }
}*/












